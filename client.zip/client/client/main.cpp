#include <iostream>
#include <WinSock2.h>
#include <WS2tcpip.h>
#include <tchar.h>
#include <thread>
#include <string>

using namespace std;

#pragma comment(lib, "ws2_32.lib")

bool Initialize() {
    WSADATA data;
    return WSAStartup(MAKEWORD(2, 2), &data) == 0;
}

void ReceiveMessages(SOCKET clientSocket) {
    char buffer[4096];
    while (true) {
        int bytesReceived = recv(clientSocket, buffer, sizeof(buffer), 0);
        if (bytesReceived > 0) {
            string message(buffer, bytesReceived);
            cout << message << endl;
        }
    }
}

int main() {
    if (!Initialize()) {
        cout << "Winsock initialization failed" << endl;
        return 1;
    }

    SOCKET clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET) {
        cout << "Socket creation failed" << endl;
        return 1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(12345);
    InetPton(AF_INET, _T("127.0.0.1"), &serverAddr.sin_addr);

    if (connect(clientSocket, reinterpret_cast<sockaddr*>(&serverAddr), sizeof(serverAddr)) == SOCKET_ERROR) {
        cout << "Connection to server failed" << endl;
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    string name;
    cout << "Enter your chat name: ";
    getline(cin, name);

    // Send the name to the server first
    send(clientSocket, name.c_str(), name.length(), 0);

    thread receiveThread(ReceiveMessages, clientSocket);
    receiveThread.detach();

    while (true) {
        string message;
        getline(cin, message);
        message = name + ": " + message;
        send(clientSocket, message.c_str(), message.length(), 0);
    }

    closesocket(clientSocket);
    WSACleanup();
    return 0;
}
